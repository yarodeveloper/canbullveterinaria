import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';
import { Head, Link, router } from '@inertiajs/react';
import React from 'react';

export default function Index({ auth, appointments, selectedDate }) {
    const [view, setView] = React.useState('list'); // 'list' or 'grid'

    const handleDateChange = (e) => {
        router.get(route('appointments.index'), { date: e.target.value }, { preserveState: true });
    };

    const statusColors = {
        scheduled: 'bg-blue-100 text-blue-700 border-blue-200',
        confirmed: 'bg-indigo-100 text-indigo-700 border-indigo-200',
        'in-progress': 'bg-yellow-100 text-yellow-700 border-yellow-200 animate-pulse',
        completed: 'bg-green-100 text-green-700 border-green-200',
        cancelled: 'bg-red-100 text-red-700 border-red-200',
        'no-show': 'bg-gray-100 text-gray-700 border-gray-200',
    };

    const typeIcons = {
        consultation: '🩺',
        surgery: '🔪',
        grooming: '🛁',
        'follow-up': '📋',
        emergency: '🚨',
    };

    const updateStatus = (id, status) => {
        router.patch(route('appointments.update', id), { status });
    };

    return (
        <AuthenticatedLayout
            user={auth.user}
            header={
                <div className="flex justify-between items-center">
                    <h2 className="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">Agenda Médica</h2>
                    <Link
                        href={route('appointments.create')}
                        className="px-4 py-2 bg-indigo-600 text-white rounded-md font-bold hover:bg-indigo-700 transition shadow-lg flex items-center gap-2"
                    >
                        <span>+</span> Nueva Cita
                    </Link>
                </div>
            }
        >
            <Head title="Agenda" />

            <div className="py-12">
                <div className="max-w-7xl mx-auto sm:px-6 lg:px-8">

                    {/* Toolbar / Date Picker & View Toggler */}
                    <div className="bg-white dark:bg-gray-800 p-4 rounded-xl shadow-sm mb-6 flex flex-wrap items-center justify-between gap-4">
                        <div className="flex items-center gap-6">
                            <div className="flex items-center gap-2">
                                <label className="text-sm font-medium text-gray-500">Fecha:</label>
                                <input
                                    type="date"
                                    value={selectedDate}
                                    onChange={handleDateChange}
                                    className="rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 dark:bg-gray-900 dark:border-gray-700"
                                />
                            </div>
                            <div className="h-8 w-px bg-gray-200 dark:border-gray-700 hidden sm:block"></div>
                            <div className="flex bg-gray-100 dark:bg-gray-900 p-1 rounded-lg">
                                <button
                                    onClick={() => setView('list')}
                                    className={`px-3 py-1.5 rounded-md text-xs font-bold transition-all ${view === 'list' ? 'bg-white dark:bg-gray-800 shadow-sm text-indigo-600' : 'text-gray-500 hover:text-gray-700'}`}
                                >
                                    Lista
                                </button>
                                <button
                                    onClick={() => setView('grid')}
                                    className={`px-3 py-1.5 rounded-md text-xs font-bold transition-all ${view === 'grid' ? 'bg-white dark:bg-gray-800 shadow-sm text-indigo-600' : 'text-gray-500 hover:text-gray-700'}`}
                                >
                                    Cuadrícula
                                </button>
                            </div>
                        </div>
                        <div className="flex gap-2">
                            <button
                                onClick={() => router.get(route('appointments.index'), { date: new Date().toISOString().split('T')[0] })}
                                className="px-4 py-2 text-sm font-medium border border-gray-300 rounded-md hover:bg-gray-50 dark:hover:bg-gray-700 transition"
                            >
                                Hoy
                            </button>
                        </div>
                    </div>

                    <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
                        {/* Appointments Area */}
                        <div className="lg:col-span-3">
                            {appointments.length === 0 ? (
                                <div className="bg-white dark:bg-gray-800 p-12 rounded-xl text-center border-2 border-dashed border-gray-200 dark:border-gray-700">
                                    <span className="text-4xl mb-4 block">📅</span>
                                    <p className="text-gray-500">No hay citas agendadas para este día.</p>
                                    <Link href={route('appointments.create')} className="text-indigo-600 font-bold mt-2 inline-block">Agendar primera cita</Link>
                                </div>
                            ) : view === 'list' ? (
                                <div className="space-y-4">
                                    {appointments.map((apt) => (
                                        <div key={apt.id} className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border-l-4 border-indigo-500 overflow-hidden hover:shadow-md transition">
                                            <div className="p-5 flex flex-wrap md:flex-nowrap gap-6 items-center">
                                                {/* Time Column */}
                                                <div className="flex flex-col items-center justify-center min-w-[80px] border-r dark:border-gray-700 pr-6">
                                                    <span className="text-lg font-black text-indigo-600">
                                                        {new Date(apt.start_time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                                                    </span>
                                                    <span className="text-xs text-gray-400 uppercase font-bold">Inicia</span>
                                                </div>

                                                {/* Pet & Info */}
                                                <div className="flex-1 min-w-0">
                                                    <div className="flex items-center gap-2 mb-1">
                                                        <span className="text-lg font-bold truncate text-gray-900 dark:text-gray-100">
                                                            {apt.pet.name}
                                                        </span>
                                                        <span className="text-xs px-2 py-0.5 rounded-full border border-gray-200 dark:border-gray-700 text-gray-500 uppercase font-medium">
                                                            {apt.pet.species}
                                                        </span>
                                                    </div>
                                                    <div className="flex flex-wrap gap-x-4 gap-y-1 text-sm text-gray-500">
                                                        <span className="flex items-center gap-1">👤 {apt.client.name}</span>
                                                        <span className="flex items-center gap-1">👨‍⚕️ {apt.veterinarian?.name || 'Por asignar'}</span>
                                                    </div>
                                                </div>

                                                {/* Type & Status */}
                                                <div className="flex flex-col items-end gap-2 shrink-0">
                                                    <div className="flex items-center gap-2">
                                                        <span className="text-xl" title={apt.type}>{typeIcons[apt.type]}</span>
                                                        <span className={`px-2.5 py-1 rounded-full text-xs font-bold border ${statusColors[apt.status]}`}>
                                                            {apt.status.toUpperCase()}
                                                        </span>
                                                    </div>

                                                    {/* Quick Actions */}
                                                    <div className="flex gap-2">
                                                        {apt.status === 'scheduled' && (
                                                            <button
                                                                onClick={() => updateStatus(apt.id, 'confirmed')}
                                                                className="text-xs bg-indigo-50 text-indigo-600 px-2 py-1 rounded hover:bg-indigo-100 transition"
                                                            >
                                                                Confirmar
                                                            </button>
                                                        )}
                                                        {apt.status === 'confirmed' && (
                                                            <button
                                                                onClick={() => updateStatus(apt.id, 'in-progress')}
                                                                className="text-xs bg-yellow-50 text-yellow-600 px-2 py-1 rounded hover:bg-yellow-100 transition"
                                                            >
                                                                Atender
                                                            </button>
                                                        )}
                                                        {apt.status === 'in-progress' && (
                                                            <button
                                                                onClick={() => updateStatus(apt.id, 'completed')}
                                                                className="text-xs bg-green-50 text-green-600 px-2 py-1 rounded hover:bg-green-100 transition"
                                                            >
                                                                Finalizar
                                                            </button>
                                                        )}
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            ) : (
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    {appointments.map((apt) => (
                                        <div key={apt.id} className="bg-white dark:bg-gray-800 rounded-2xl p-5 shadow-sm border border-gray-100 dark:border-gray-700 flex flex-col justify-between hover:shadow-md transition group">
                                            <div className="flex justify-between items-start mb-4">
                                                <div className="flex items-center gap-3">
                                                    <div className="w-12 h-12 bg-indigo-50 dark:bg-indigo-900/30 rounded-xl flex items-center justify-center text-2xl">
                                                        {typeIcons[apt.type]}
                                                    </div>
                                                    <div>
                                                        <p className="font-black text-gray-900 dark:text-gray-100">{apt.pet.name}</p>
                                                        <p className="text-xs text-gray-400 font-bold uppercase">{apt.pet.species}</p>
                                                    </div>
                                                </div>
                                                <span className={`px-2 py-1 rounded-lg text-[10px] font-black border ${statusColors[apt.status]}`}>
                                                    {apt.status.toUpperCase()}
                                                </span>
                                            </div>

                                            <div className="space-y-2 mb-6">
                                                <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400">
                                                    <span className="text-xs">⏰</span>
                                                    <span className="font-bold">{new Date(apt.start_time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                                                </div>
                                                <div className="flex items-center gap-2 text-xs text-gray-500">
                                                    <span>👤</span>
                                                    <span className="truncate">Dueño: {apt.client.name}</span>
                                                </div>
                                                <div className="flex items-center gap-2 text-xs text-gray-500">
                                                    <span>👨‍⚕️</span>
                                                    <span className="truncate">Vet: {apt.veterinarian?.name || 'Por asignar'}</span>
                                                </div>
                                            </div>

                                            <div className="flex gap-2 border-t dark:border-gray-700 pt-4">
                                                {apt.status === 'scheduled' && (
                                                    <button onClick={() => updateStatus(apt.id, 'confirmed')} className="flex-1 py-2 text-[10px] font-black bg-indigo-50 text-indigo-600 rounded-lg hover:bg-indigo-100 uppercase tracking-wider">Confirmar</button>
                                                )}
                                                {apt.status === 'confirmed' && (
                                                    <button onClick={() => updateStatus(apt.id, 'in-progress')} className="flex-1 py-2 text-[10px] font-black bg-yellow-50 text-yellow-600 rounded-lg hover:bg-yellow-100 uppercase tracking-wider">Atender</button>
                                                )}
                                                {apt.status === 'in-progress' && (
                                                    <button onClick={() => updateStatus(apt.id, 'completed')} className="flex-1 py-2 text-[10px] font-black bg-green-50 text-green-600 rounded-lg hover:bg-green-100 uppercase tracking-wider">Finalizar</button>
                                                )}
                                                <Link href={route('pets.show', apt.pet.id)} className="p-2 text-gray-400 hover:text-indigo-600">
                                                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" /></svg></Link>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            )}
                        </div>

                        {/* Summary / Stats for the day */}
                        <div className="space-y-6">
                            <div className="bg-indigo-600 rounded-2xl p-6 text-white shadow-xl">
                                <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
                                    <span>📊</span> Resumen del Día
                                </h3>
                                <div className="space-y-4">
                                    <div className="flex justify-between items-center border-b border-white/10 pb-2">
                                        <span className="text-indigo-100">Total Citas</span>
                                        <span className="text-2xl font-black">{appointments.length}</span>
                                    </div>
                                    <div className="flex justify-between items-center border-b border-white/10 pb-2">
                                        <span className="text-indigo-100">Pendientes</span>
                                        <span className="text-2xl font-black">
                                            {appointments.filter(a => ['scheduled', 'confirmed'].includes(a.status)).length}
                                        </span>
                                    </div>
                                    <div className="flex justify-between items-center">
                                        <span className="text-indigo-100">Completadas</span>
                                        <span className="text-2xl font-black">
                                            {appointments.filter(a => a.status === 'completed').length}
                                        </span>
                                    </div>
                                </div>
                            </div>

                            <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 shadow-sm border border-gray-100 dark:border-gray-700">
                                <h3 className="text-sm font-bold text-gray-400 uppercase tracking-widest mb-4">Ayuda Rápida</h3>
                                <ul className="space-y-3 text-sm">
                                    <li className="flex items-center gap-2">🩺 Consulta Médica</li>
                                    <li className="flex items-center gap-2">🛁 Estética / Baño</li>
                                    <li className="flex items-center gap-2">🔪 Cirugía Programada</li>
                                    <li className="flex items-center gap-2">🚨 Urgencia</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </AuthenticatedLayout>
    );
}
