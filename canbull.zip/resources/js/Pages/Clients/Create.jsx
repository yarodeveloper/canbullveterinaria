import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';
import { Head, useForm, Link } from '@inertiajs/react';

export default function Create({ auth }) {
    const { data, setData, post, processing, errors } = useForm({
        name: '',
        email: '',
        phone: '',
        address: '',
        emergency_contact_name: '',
        emergency_contact_phone: '',
        tax_id: '',
        crm_notes: '',
    });

    const submit = (e) => {
        e.preventDefault();
        post(route('clients.store'));
    };

    return (
        <AuthenticatedLayout
            user={auth.user}
            header={<h2 className="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">Registrar Nuevo Cliente</h2>}
        >
            <Head title="Nuevo Cliente" />

            <div className="py-12">
                <div className="max-w-4xl mx-auto sm:px-6 lg:px-8">
                    <div className="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                        <form onSubmit={submit} className="p-6">
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">

                                {/* Datos Personales */}
                                <div className="space-y-4">
                                    <h3 className="text-sm font-bold uppercase text-gray-400 border-b pb-2">Información de Contacto</h3>
                                    <div>
                                        <label className="block text-sm font-medium">Nombre Completo *</label>
                                        <input
                                            type="text"
                                            value={data.name}
                                            onChange={e => setData('name', e.target.value)}
                                            className="mt-1 block w-full rounded-md border-gray-300 dark:bg-gray-900 dark:border-gray-700"
                                            required
                                        />
                                        {errors.name && <div className="text-red-500 text-xs mt-1">{errors.name}</div>}
                                    </div>
                                    <div>
                                        <label className="block text-sm font-medium">Correo Electrónico *</label>
                                        <input
                                            type="email"
                                            value={data.email}
                                            onChange={e => setData('email', e.target.value)}
                                            className="mt-1 block w-full rounded-md border-gray-300 dark:bg-gray-900 dark:border-gray-700"
                                            required
                                        />
                                        {errors.email && <div className="text-red-500 text-xs mt-1">{errors.email}</div>}
                                    </div>
                                    <div>
                                        <label className="block text-sm font-medium">Teléfono Celular</label>
                                        <input
                                            type="text"
                                            value={data.phone}
                                            onChange={e => setData('phone', e.target.value)}
                                            className="mt-1 block w-full rounded-md border-gray-300 dark:bg-gray-900 dark:border-gray-700"
                                        />
                                    </div>
                                    <div>
                                        <label className="block text-sm font-medium">Dirección</label>
                                        <textarea
                                            value={data.address}
                                            onChange={e => setData('address', e.target.value)}
                                            rows="2"
                                            className="mt-1 block w-full rounded-md border-gray-300 dark:bg-gray-900 dark:border-gray-700"
                                        ></textarea>
                                    </div>
                                </div>

                                {/* Seguridad y CRM */}
                                <div className="space-y-4">
                                    <h3 className="text-sm font-bold uppercase text-gray-400 border-b pb-2">Urgencias y CRM</h3>
                                    <div className="bg-red-50 dark:bg-red-900/10 p-4 rounded-lg space-y-3">
                                        <div>
                                            <label className="block text-xs font-bold text-red-700">Contacto de Emergencia</label>
                                            <input
                                                type="text"
                                                value={data.emergency_contact_name}
                                                onChange={e => setData('emergency_contact_name', e.target.value)}
                                                placeholder="Nombre"
                                                className="mt-1 block w-full rounded-md border-gray-200 dark:bg-gray-900 dark:border-gray-700 text-sm"
                                            />
                                        </div>
                                        <div>
                                            <label className="block text-xs font-bold text-red-700">Teléfono Emergencia</label>
                                            <input
                                                type="text"
                                                value={data.emergency_contact_phone}
                                                onChange={e => setData('emergency_contact_phone', e.target.value)}
                                                placeholder="Teléfono"
                                                className="mt-1 block w-full rounded-md border-gray-200 dark:bg-gray-900 dark:border-gray-700 text-sm"
                                            />
                                        </div>
                                    </div>
                                    <div>
                                        <label className="block text-sm font-medium">RFC / Tax ID</label>
                                        <input
                                            type="text"
                                            value={data.tax_id}
                                            onChange={e => setData('tax_id', e.target.value)}
                                            className="mt-1 block w-full rounded-md border-gray-300 dark:bg-gray-900 dark:border-gray-700 uppercase"
                                        />
                                    </div>
                                    <div>
                                        <label className="block text-sm font-medium text-gray-400 italic">Notas Internas (CRM)</label>
                                        <textarea
                                            value={data.crm_notes}
                                            onChange={e => setData('crm_notes', e.target.value)}
                                            rows="3"
                                            className="mt-1 block w-full rounded-md border-gray-300 dark:bg-gray-900 dark:border-gray-700 text-sm"
                                        ></textarea>
                                    </div>
                                </div>
                            </div>

                            <div className="mt-8 flex items-center justify-end space-x-4 border-t pt-6 text-gray-900 dark:text-gray-100 dark:border-gray-700">
                                <Link
                                    href={route('clients.index')}
                                    className="text-sm text-gray-600 dark:text-gray-400 hover:text-gray-900 underline"
                                >
                                    Cancelar
                                </Link>
                                <button
                                    type="submit"
                                    disabled={processing}
                                    className="px-8 py-2 bg-indigo-600 text-white rounded-md font-bold hover:bg-indigo-700 transition"
                                >
                                    Registrar Cliente
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </AuthenticatedLayout>
    );
}
