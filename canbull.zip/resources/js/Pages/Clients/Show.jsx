import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';
import { Head, Link } from '@inertiajs/react';

export default function Show({ auth, client }) {
    return (
        <AuthenticatedLayout
            user={auth.user}
            header={<h2 className="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">Perfil de Cliente: {client.name}</h2>}
        >
            <Head title={`Cliente - ${client.name}`} />

            <div className="py-12">
                <div className="max-w-7xl mx-auto sm:px-6 lg:px-8 space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">

                        {/* Datos de Contacto y CRM */}
                        <div className="md:col-span-1 space-y-6">
                            <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm border dark:border-gray-700">
                                <h3 className="text-sm font-bold uppercase text-gray-400 mb-4 tracking-widest">Información de Contacto</h3>
                                <div className="space-y-4">
                                    <div>
                                        <p className="text-xs text-gray-500">Teléfono Principal</p>
                                        <p className="font-bold text-lg">{client.phone || 'No registrado'}</p>
                                    </div>
                                    <div>
                                        <p className="text-xs text-gray-500">Correo Electrónico</p>
                                        <p className="font-medium underline text-indigo-600">{client.email}</p>
                                    </div>
                                    <div>
                                        <p className="text-xs text-gray-500">Dirección Física</p>
                                        <p className="text-sm">{client.address || 'Sin dirección registrada'}</p>
                                    </div>
                                    <div className="pt-4 border-t dark:border-gray-700">
                                        <p className="text-xs text-gray-500">RFC / Tax ID</p>
                                        <p className="font-mono text-sm uppercase">{client.tax_id || 'N/A'}</p>
                                    </div>
                                </div>
                            </div>

                            <div className="bg-red-50 dark:bg-red-900/20 p-6 rounded-lg shadow-sm border border-red-100 dark:border-red-900/30">
                                <h3 className="text-sm font-bold uppercase text-red-600 dark:text-red-400 mb-4 tracking-widest flex items-center">
                                    <span className="mr-2">⚠️</span> Contacto de Emergencia
                                </h3>
                                <div className="space-y-2">
                                    <p className="text-sm font-bold">{client.emergency_contact_name || 'No definido'}</p>
                                    <p className="text-lg font-black text-red-700 dark:text-red-300">{client.emergency_contact_phone || '---'}</p>
                                </div>
                            </div>

                            <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm border dark:border-gray-700">
                                <h3 className="text-sm font-bold uppercase text-gray-400 mb-4 tracking-widest">Observaciones CRM</h3>
                                <p className="text-sm italic text-gray-600 dark:text-gray-400">
                                    {client.crm_notes || 'Sin notas internas.'}
                                </p>
                            </div>
                        </div>

                        {/* Listado de Mascotas (Pacientes) */}
                        <div className="md:col-span-2 space-y-6">
                            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm overflow-hidden border dark:border-gray-700">
                                <div className="p-6 border-b dark:border-gray-700 flex justify-between items-center bg-gray-50 dark:bg-gray-900/50">
                                    <h3 className="text-lg font-bold">Mascotas Vinculadas</h3>
                                    <Link
                                        href={route('pets.create', { user_id: client.id })}
                                        className="text-xs bg-indigo-600 text-white px-3 py-1 rounded font-bold uppercase tracking-tighter"
                                    >
                                        + Agregar Mascota
                                    </Link>
                                </div>
                                <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-4">
                                    {client.pets.map(pet => (
                                        <Link
                                            key={pet.id}
                                            href={route('pets.show', pet.id)}
                                            className="group flex items-center p-4 border dark:border-gray-700 rounded-xl hover:border-indigo-500 transition-all hover:shadow-md"
                                        >
                                            <div className="h-14 w-14 bg-indigo-50 dark:bg-indigo-900/30 rounded-full flex items-center justify-center text-indigo-600 text-xl font-black italic">
                                                {pet.name.charAt(0)}
                                            </div>
                                            <div className="ml-4 flex-grow">
                                                <div className="flex justify-between items-start">
                                                    <p className="font-black text-gray-800 dark:text-white group-hover:text-indigo-600 transition">{pet.name}</p>
                                                    {pet.is_aggressive && (
                                                        <span className="text-[10px] bg-red-100 text-red-600 px-1 rounded uppercase font-bold animate-pulse">Aggressive</span>
                                                    )}
                                                </div>
                                                <p className="text-xs text-gray-500">{pet.species} • {pet.breed || 'Mestizo'}</p>
                                                <div className="mt-2 flex space-x-3 text-[10px] uppercase font-bold text-gray-400">
                                                    <span>📋 {pet.medical_records_count} Consultas</span>
                                                    <span>📅 {pet.appointments_count} Citas</span>
                                                </div>
                                            </div>
                                        </Link>
                                    ))}
                                    {client.pets.length === 0 && (
                                        <div className="col-span-2 text-center py-10 text-gray-400 italic">
                                            Este cliente aún no tiene mascotas registradas.
                                        </div>
                                    )}
                                </div>
                            </div>

                            {/* Facturacion Rapida (Placeholder para futuro) */}
                            <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm border dark:border-gray-700 opacity-60">
                                <div className="flex justify-between items-center mb-4">
                                    <h3 className="text-sm font-bold uppercase text-gray-400 tracking-widest">Resumen Financiero</h3>
                                    <span className="text-xs bg-yellow-100 text-yellow-700 px-2 py-1 rounded">Próximamente</span>
                                </div>
                                <div className="grid grid-cols-3 gap-4 text-center">
                                    <div>
                                        <p className="text-xs text-gray-500">Saldo Pendiente</p>
                                        <p className="text-lg font-black text-red-600">$0.00</p>
                                    </div>
                                    <div>
                                        <p className="text-xs text-gray-500">Último Pago</p>
                                        <p className="text-sm font-bold">-</p>
                                    </div>
                                    <div>
                                        <p className="text-xs text-gray-500">Total Histórico</p>
                                        <p className="text-sm font-bold">$0.00</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </AuthenticatedLayout>
    );
}
