import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';
import { Head, useForm } from '@inertiajs/react';
import React from 'react';

export default function Web({ auth, settings }) {
    const { data, setData, patch, processing, recentlySuccessful } = useForm({
        settings: settings.map(s => ({ id: s.id, key: s.key, value: s.value, label: s.label, type: s.type, group: s.group }))
    });

    const handleValueChange = (index, value) => {
        const newSettings = [...data.settings];
        newSettings[index].value = value;
        setData('settings', newSettings);
    };

    const submit = (e) => {
        e.preventDefault();
        patch(route('settings.web.update'));
    };

    // Group settings by group
    const groupedSettings = data.settings.reduce((acc, s) => {
        if (!acc[s.group]) acc[s.group] = [];
        acc[s.group].push(s);
        return acc;
    }, {});

    const groupNames = {
        hero: 'Sección Hero (Principal)',
        contact: 'Información de Contacto',
        services: 'Textos de Servicios',
        promos: 'Ofertas y Promociones',
    };

    return (
        <AuthenticatedLayout
            user={auth.user}
            header={<h2 className="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">Gestión de Página Web Pública</h2>}
        >
            <Head title="Gestión Web" />

            <div className="py-12">
                <div className="max-w-4xl mx-auto sm:px-6 lg:px-8">
                    <form onSubmit={submit} className="space-y-8">
                        {Object.entries(groupedSettings).map(([group, items]) => (
                            <div key={group} className="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                                <div className="p-6">
                                    <h3 className="text-lg font-bold border-b dark:border-gray-700 pb-2 mb-6 text-indigo-600 uppercase tracking-wider">
                                        {groupNames[group] || group}
                                    </h3>

                                    <div className="space-y-6">
                                        {items.map((setting) => {
                                            const globalIndex = data.settings.findIndex(s => s.id === setting.id);
                                            return (
                                                <div key={setting.id}>
                                                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                                                        {setting.label}
                                                    </label>
                                                    {setting.type === 'textarea' ? (
                                                        <textarea
                                                            value={setting.value || ''}
                                                            onChange={e => handleValueChange(globalIndex, e.target.value)}
                                                            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 dark:bg-gray-900 dark:border-gray-700"
                                                            rows="3"
                                                        ></textarea>
                                                    ) : (
                                                        <input
                                                            type="text"
                                                            value={setting.value || ''}
                                                            onChange={e => handleValueChange(globalIndex, e.target.value)}
                                                            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 dark:bg-gray-900 dark:border-gray-700"
                                                        />
                                                    )}
                                                    <p className="text-xs text-gray-400 mt-1 italic">Clave técnica: {setting.key}</p>
                                                </div>
                                            );
                                        })}
                                    </div>
                                </div>
                            </div>
                        ))}

                        <div className="flex items-center justify-end gap-4">
                            {recentlySuccessful && (
                                <p className="text-sm text-green-600 animate-fade-out">Cambios guardados con éxito.</p>
                            )}
                            <button
                                type="submit"
                                disabled={processing}
                                className="px-6 py-2 bg-indigo-600 text-white rounded-md font-semibold hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 disabled:opacity-50 transition shadow-lg"
                            >
                                {processing ? 'Guardando...' : 'Guardar Todos los Cambios'}
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </AuthenticatedLayout>
    );
}
