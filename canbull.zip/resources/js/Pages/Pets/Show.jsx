import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';
import { Head, Link } from '@inertiajs/react';
import { IconEye, IconPlus, IconEdit } from '@/Components/Icons';
import PreventiveControl from './Partials/PreventiveControl';

export default function Show({ auth, pet, protocols }) {
    return (
        <AuthenticatedLayout
            user={auth.user}
            header={
                <div className="flex justify-between items-center">
                    <h2 className="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
                        Expediente: {pet.name}
                    </h2>
                    <div className="flex space-x-2">
                        <Link
                            href={route('pets.edit', pet.id)}
                            className="inline-flex items-center px-3 py-2 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-md font-semibold text-xs text-gray-700 dark:text-gray-300 uppercase tracking-widest shadow-sm hover:bg-gray-50 dark:hover:bg-gray-700 transition"
                            title="Editar Datos"
                        >
                            <IconEdit className="w-4 h-4 mr-1" /> Editar
                        </Link>
                        <Link
                            href={route('medical-records.create', pet.id)}
                            className="inline-flex items-center px-4 py-2 bg-indigo-600 border border-transparent rounded-md font-bold text-xs text-white uppercase tracking-widest hover:bg-indigo-700 transition shadow-lg"
                            title="Nueva Consulta"
                        >
                            <IconPlus className="w-4 h-4 mr-1" /> Nueva Consulta
                        </Link>
                    </div>
                </div>
            }
        >
            <Head title={`Expediente: ${pet.name}`} />

            <div className="py-12">
                <div className="max-w-7xl mx-auto sm:px-6 lg:px-8 space-y-6">

                    {/* Alertas Clinicas */}
                    {(pet.is_aggressive || pet.allergies || pet.chronic_conditions) && (
                        <div className="bg-red-600 text-white p-4 rounded-lg shadow-lg flex items-center justify-between animate-pulse">
                            <div className="flex items-center">
                                <span className="text-2xl mr-4 text-yellow-300">⚠️</span>
                                <div>
                                    <p className="font-black uppercase tracking-tighter">Alerta Clínica Crítica</p>
                                    <div className="text-sm font-medium flex space-x-4">
                                        {pet.is_aggressive && <span className="underline decoration-yellow-400">AGRESIVO</span>}
                                        {pet.allergies && <span>ALERGIAS: {pet.allergies}</span>}
                                        {pet.chronic_conditions && <span>CRÓNICO: {pet.chronic_conditions}</span>}
                                    </div>
                                </div>
                            </div>
                        </div>
                    )}
                    {/* Tarjeta de Resumen */}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <div className="md:col-span-1 space-y-6">
                            <div className="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg p-6 border dark:border-gray-700">
                                <div className="flex flex-col items-center">
                                    <div className="h-32 w-32 bg-indigo-100 dark:bg-indigo-900 rounded-full flex items-center justify-center text-5xl text-indigo-600 dark:text-indigo-300 font-bold mb-4">
                                        {pet.name.charAt(0)}
                                    </div>
                                    <h3 className="text-2xl font-bold">{pet.name}</h3>
                                    <p className="text-gray-500">{pet.species} - {pet.breed || 'Mestizo'}</p>
                                </div>

                                <div className="mt-8 space-y-3">
                                    <div className="flex justify-between text-sm">
                                        <span className="text-gray-500 font-medium">Género:</span>
                                        <span>{pet.gender === 'male' ? 'Macho' : pet.gender === 'female' ? 'Hembra' : 'Desconocido'}</span>
                                    </div>
                                    <div className="flex justify-between text-sm">
                                        <span className="text-gray-500 font-medium">Edad:</span>
                                        <span>{pet.dob ? new Date(pet.dob).toLocaleDateString() : 'Desconocida'}</span>
                                    </div>
                                    <div className="flex justify-between text-sm">
                                        <span className="text-gray-500 font-medium">Peso:</span>
                                        <span className="font-bold text-indigo-600">{pet.weight ? `${pet.weight} kg` : '-'}</span>
                                    </div>
                                    <div className="pt-4 mt-4 border-t dark:border-gray-700">
                                        <p className="text-xs text-gray-400 uppercase font-bold mb-2">Notas del Paciente</p>
                                        <p className="text-sm italic text-gray-600 dark:text-gray-400">
                                            {pet.notes || 'Sin notas adicionales.'}
                                        </p>
                                    </div>
                                </div>
                            </div>

                            <div className="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg p-6 border dark:border-gray-700">
                                <h3 className="text-sm font-bold uppercase text-gray-400 mb-4 tracking-widest">Hub Familiar</h3>
                                <div className="space-y-4">
                                    {pet.owners.map(owner => (
                                        <div key={owner.id} className="flex items-center justify-between border-b dark:border-gray-700 pb-2">
                                            <div>
                                                <Link href={route('clients.show', owner.id)} className="text-sm font-bold text-indigo-600 hover:underline block">
                                                    {owner.name}
                                                </Link>
                                                <p className="text-[10px] text-gray-500 uppercase">{owner.pivot.relation_type} {owner.pivot.is_primary ? '(Principal)' : ''}</p>
                                            </div>
                                            <a href={`tel:${owner.phone}`} className="text-xs bg-green-50 text-green-600 p-1 rounded font-bold">
                                                📞
                                            </a>
                                        </div>
                                    ))}
                                </div>
                                <button className="mt-4 w-full text-[10px] border border-dashed border-gray-300 p-2 rounded text-gray-400 hover:text-indigo-600 transition uppercase font-bold">
                                    + Vincular Familiar
                                </button>
                            </div>

                            {/* Link Público y QR */}
                            <div className="bg-indigo-600 rounded-2xl p-6 text-white shadow-xl relative overflow-hidden group">
                                <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:scale-110 transition-transform">
                                    <svg className="w-20 h-20" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8z" /></svg>
                                </div>
                                <h3 className="text-sm font-black uppercase tracking-widest mb-4">Carnet Público</h3>
                                <div className="bg-white p-3 rounded-xl mb-4 inline-block">
                                    <img
                                        src={`https://chart.googleapis.com/chart?chs=100x100&cht=qr&chl=${encodeURIComponent(window.location.origin + '/carnet/' + pet.uuid)}&choe=UTF-8`}
                                        alt="QR Link"
                                        className="w-24 h-24"
                                    />
                                </div>
                                <p className="text-[10px] font-bold text-indigo-100 uppercase mb-4 leading-relaxed">
                                    Escanea para ver en el móvil o comparte el link con el dueño.
                                </p>
                                <div className="flex gap-2">
                                    <button
                                        onClick={() => {
                                            navigator.clipboard.writeText(window.location.origin + '/carnet/' + pet.uuid);
                                            alert('Link copiado al portapapeles');
                                        }}
                                        className="flex-1 bg-white/20 hover:bg-white/30 py-2 rounded-lg text-xs font-black uppercase transition"
                                    >
                                        Copiar Link
                                    </button>
                                    <a
                                        href={route('public.carnet', pet.uuid)}
                                        target="_blank"
                                        className="flex-1 bg-white text-indigo-600 hover:bg-indigo-50 py-2 rounded-lg text-xs font-black uppercase text-center transition"
                                    >
                                        Ver Vista
                                    </a>
                                </div>
                            </div>
                        </div>

                        {/* Historial Clinico y Citas */}
                        <div className="md:col-span-2 space-y-6">
                            <div className="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-[2.5rem] border dark:border-gray-700">
                                <div className="p-8 border-b dark:border-gray-700 flex justify-between items-center bg-gray-50/50 dark:bg-gray-900/20">
                                    <div className="flex items-center gap-3">
                                        <div className="p-3 bg-emerald-100 dark:bg-emerald-900/50 rounded-2xl text-2xl">🩺</div>
                                        <div>
                                            <h3 className="text-xl font-black uppercase tracking-tight">Historia Clínica (SOAP)</h3>
                                            <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest">Registros de evolución y diagnóstico</p>
                                        </div>
                                    </div>
                                    <Link
                                        href={route('medical-records.create', pet.id)}
                                        className="bg-emerald-600 text-white px-6 py-3 rounded-2xl text-xs font-black uppercase tracking-widest hover:bg-emerald-700 transition shadow-lg shadow-emerald-200 dark:shadow-none"
                                    >
                                        + Nueva Consulta
                                    </Link>
                                </div>
                                <div className="p-8">
                                    {pet.medical_records?.length > 0 ? (
                                        <div className="space-y-12 relative">
                                            {/* Vertical Line */}
                                            <div className="absolute left-6 top-4 bottom-4 w-px bg-gray-100 dark:bg-gray-700"></div>

                                            {pet.medical_records.map(record => (
                                                <div key={record.id} className="relative pl-16 group">
                                                    {/* Dot */}
                                                    <div className="absolute left-4 top-1 w-4 h-4 rounded-full border-4 border-white dark:border-gray-800 bg-emerald-500 z-10 group-hover:scale-125 transition-transform"></div>

                                                    <div className="bg-white dark:bg-gray-900/30 p-6 rounded-3xl border border-gray-100 dark:border-gray-800 hover:border-emerald-200 dark:hover:border-emerald-900 transition-all hover:shadow-xl hover:shadow-emerald-500/5">
                                                        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
                                                            <div>
                                                                <div className="flex items-center gap-3 mb-1">
                                                                    <span className="text-sm font-black text-gray-900 dark:text-gray-100 uppercase tracking-tighter">
                                                                        {new Date(record.created_at).toLocaleDateString(undefined, { day: 'numeric', month: 'long', year: 'numeric' })}
                                                                    </span>
                                                                    <span className={`text-[10px] px-2 py-0.5 rounded-full font-black uppercase tracking-widest border ${record.type === 'emergency' ? 'bg-red-50 text-red-600 border-red-100' : 'bg-indigo-50 text-indigo-600 border-indigo-100'
                                                                        }`}>
                                                                        {record.type}
                                                                    </span>
                                                                </div>
                                                                <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest italic">Responsable: Dr. {record.veterinarian.name}</p>
                                                            </div>
                                                            <Link
                                                                href={route('medical-records.show', record.id)}
                                                                className="px-4 py-2 bg-emerald-50 text-emerald-600 hover:bg-emerald-100 rounded-xl text-[10px] font-black uppercase tracking-widest transition flex items-center gap-2"
                                                            >
                                                                Ver Detalles <IconEye className="w-3 h-3" />
                                                            </Link>
                                                        </div>

                                                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                                            <div className="space-y-4">
                                                                <div>
                                                                    <p className="text-[9px] font-black text-indigo-400 uppercase tracking-widest mb-1 flex items-center gap-1">
                                                                        <span className="w-1.5 h-1.5 bg-indigo-400 rounded-full"></span> Subjetivo
                                                                    </p>
                                                                    <p className="text-sm text-gray-600 dark:text-gray-400 line-clamp-2 italic">"{record.subjective}"</p>
                                                                </div>
                                                                <div>
                                                                    <p className="text-[9px] font-black text-emerald-400 uppercase tracking-widest mb-1 flex items-center gap-1">
                                                                        <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full"></span> Hallazgos (Obj)
                                                                    </p>
                                                                    <p className="text-sm text-gray-600 dark:text-gray-400 line-clamp-2">{record.objective}</p>
                                                                </div>
                                                            </div>
                                                            <div className="space-y-4">
                                                                <div>
                                                                    <p className="text-[9px] font-black text-amber-400 uppercase tracking-widest mb-1 flex items-center gap-1">
                                                                        <span className="w-1.5 h-1.5 bg-amber-400 rounded-full"></span> Diagnóstico (Anal)
                                                                    </p>
                                                                    <p className="text-sm font-bold text-gray-800 dark:text-gray-200 line-clamp-2">{record.assessment}</p>
                                                                </div>
                                                                <div>
                                                                    <p className="text-[9px] font-black text-rose-400 uppercase tracking-widest mb-1 flex items-center gap-1">
                                                                        <span className="w-1.5 h-1.5 bg-rose-400 rounded-full"></span> Plan Médico
                                                                    </p>
                                                                    <p className="text-sm text-gray-600 dark:text-gray-400 line-clamp-2">{record.plan}</p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            ))}
                                        </div>
                                    ) : (
                                        <div className="text-center py-16 border-4 border-dashed border-gray-50 dark:border-gray-800 rounded-[2.5rem]">
                                            <span className="text-5xl mb-4 block opacity-20">🩺</span>
                                            <p className="text-gray-400 font-bold uppercase tracking-widest text-xs">Sin registros clínicos aún</p>
                                            <p className="text-gray-400 text-sm mt-1">Inicia la primera consulta para crear su historial.</p>
                                        </div>
                                    )}
                                </div>
                            </div>

                            <PreventiveControl pet={pet} auth={auth} protocols={protocols} />

                            <div className="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                                <div className="p-6 border-b dark:border-gray-700 flex justify-between items-center">
                                    <h3 className="text-lg font-bold">Documentos y Consentimientos</h3>
                                    <div className="flex space-x-2">
                                        <Link
                                            href={route('consents.create', [pet.id, { type: 'surgery' }])}
                                            className="text-xs bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 p-2 rounded"
                                        >
                                            + Cx
                                        </Link>
                                        <Link
                                            href={route('consents.create', [pet.id, { type: 'euthanasia' }])}
                                            className="text-xs bg-red-50 text-red-600 hover:bg-red-100 p-2 rounded"
                                        >
                                            + Eutanasia
                                        </Link>
                                    </div>
                                </div>
                                <div className="p-6">
                                    {pet.consents?.length > 0 ? (
                                        <ul className="divide-y dark:divide-gray-700">
                                            {pet.consents.map(consent => (
                                                <li key={consent.id} className="py-3 flex justify-between items-center">
                                                    <div>
                                                        <p className="font-medium text-sm capitalize">{consent.type}</p>
                                                        <p className="text-xs text-gray-500">Firmado el {new Date(consent.signed_at).toLocaleDateString()}</p>
                                                    </div>
                                                    <div className="flex space-x-1">
                                                        <Link
                                                            href={route('consents.show', consent.id)}
                                                            className="p-1 text-indigo-600 hover:bg-indigo-50 rounded transition"
                                                            title="Ver Detalle"
                                                        >
                                                            <IconEye className="w-5 h-5" />
                                                        </Link>
                                                        <Link
                                                            href="#"
                                                            className="p-1 text-gray-400 hover:bg-gray-50 rounded transition"
                                                            title="Imprimir"
                                                        >
                                                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
                                                                <path strokeLinecap="round" strokeLinejoin="round" d="M6.72 13.89l-2.1 2.1c-.245.245-.245.642 0 .887l.062.062a.627.627 0 00.887 0l2.1-2.1M6.72 13.89l3.52 3.52c.245.245.642.245.887 0l.062-.062a.627.627 0 000-.887l-3.52-3.52m3.52-3.52l2.1-2.1c.245-.245.245-.642 0-.887l-.062-.062a.627.627 0 00-.887 0l-2.1 2.1M10.24 10.37l-3.52 3.52" />
                                                            </svg>
                                                        </Link>
                                                    </div>
                                                </li>
                                            ))}
                                        </ul>
                                    ) : (
                                        <p className="text-gray-500 text-center py-4 text-sm italic">No hay documentos firmados aún.</p>
                                    )}
                                </div>
                            </div>

                            <div className="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                                <div className="p-6 border-b dark:border-gray-700 flex justify-between items-center">
                                    <h3 className="text-lg font-bold">Próximas Citas</h3>
                                    <Link href={route('appointments.index')} className="text-indigo-600 text-sm font-bold hover:underline">Ver Calendario</Link>
                                </div>
                                <div className="p-6">
                                    {pet.appointments?.length > 0 ? (
                                        <div className="space-y-3">
                                            {pet.appointments.map(app => (
                                                <div key={app.id} className="flex justify-between items-center p-3 rounded-xl border dark:border-gray-700 bg-gray-50 dark:bg-gray-900/50">
                                                    <div className="flex items-center gap-3">
                                                        <div className="bg-indigo-100 dark:bg-indigo-900/30 p-2 rounded-lg text-indigo-600 font-black text-xs text-center min-w-[50px]">
                                                            {new Date(app.start_time).toLocaleDateString([], { day: '2-digit', month: 'short' })}
                                                        </div>
                                                        <div>
                                                            <p className="font-bold text-sm text-gray-900 dark:text-gray-100">
                                                                {new Date(app.start_time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                                                            </p>
                                                            <p className="text-[10px] text-gray-500 uppercase font-black">{app.type}</p>
                                                        </div>
                                                    </div>
                                                    <span className={`px-2 py-0.5 text-[10px] font-black uppercase rounded-full border ${app.status === 'scheduled' ? 'bg-blue-50 text-blue-600 border-blue-200' :
                                                        app.status === 'confirmed' ? 'bg-indigo-50 text-indigo-600 border-indigo-200' :
                                                            'bg-gray-50 text-gray-500 border-gray-200'
                                                        }`}>
                                                        {app.status}
                                                    </span>
                                                </div>
                                            ))}
                                        </div>
                                    ) : (
                                        <div className="text-center py-6">
                                            <p className="text-gray-500 text-sm italic mb-4">No hay citas programadas.</p>
                                            <Link
                                                href={route('appointments.create', { pet_id: pet.id })}
                                                className="text-xs font-bold text-indigo-600 uppercase tracking-widest bg-indigo-50 px-4 py-2 rounded-lg"
                                            >
                                                + Agendar Cita
                                            </Link>
                                        </div>
                                    )}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </AuthenticatedLayout>
    );
}
