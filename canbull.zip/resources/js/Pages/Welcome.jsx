import { Head, Link } from '@inertiajs/react';
import React from 'react';

export default function Welcome({ auth, settings }) {
    const s = settings || {};

    // Helper for safe access
    const getSetting = (key, fallback) => s[key] || fallback;

    return (
        <div className="min-h-screen bg-white text-gray-900 dark:bg-gray-950 dark:text-gray-100 font-sans selection:bg-indigo-500 selection:text-white">
            <Head>
                <title>{getSetting('hero_title', 'Veterinaria Canbull')}</title>
                <meta name="description" content={getSetting('hero_subtitle', 'Cuidado experto para tus mascotas')} />
            </Head>

            {/* Top Promo Banner */}
            {getSetting('promo_active', '0') === '1' && (
                <div className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white py-2 px-4 text-center text-sm font-medium animate-pulse">
                    <span className="inline-flex items-center gap-2">
                        <span className="hidden sm:inline">📢</span>
                        {getSetting('promo_text', '¡Aprovecha nuestras ofertas del mes!')}
                    </span>
                </div>
            )}

            {/* Navigation */}
            <nav className="sticky top-0 z-50 bg-white/80 dark:bg-gray-950/80 backdrop-blur-md border-b border-gray-100 dark:border-gray-800">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="flex h-20 justify-between items-center">
                        <div className="flex items-center gap-2">
                            <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center text-white text-xl font-bold shadow-lg shadow-indigo-200 dark:shadow-none">
                                C
                            </div>
                            <span className="text-2xl font-black tracking-tighter bg-clip-text text-transparent bg-gradient-to-r from-indigo-600 to-indigo-400">
                                CANBULL
                            </span>
                        </div>

                        <div className="hidden md:flex items-center space-x-8">
                            <a href="#servicios" className="text-sm font-semibold hover:text-indigo-600 transition">Servicios</a>
                            <a href="#contacto" className="text-sm font-semibold hover:text-indigo-600 transition">Contacto</a>
                            {auth.user ? (
                                <Link
                                    href={route('dashboard')}
                                    className="px-5 py-2.5 bg-indigo-600 text-white rounded-full text-sm font-bold hover:bg-indigo-700 transition shadow-lg shadow-indigo-200 dark:shadow-none"
                                >
                                    Ir al Panel
                                </Link>
                            ) : (
                                <Link
                                    href={route('login')}
                                    className="px-5 py-2.5 bg-gray-900 dark:bg-white dark:text-gray-900 text-white rounded-full text-sm font-bold hover:opacity-90 transition shadow-xl"
                                >
                                    Iniciar Sesión
                                </Link>
                            )}
                        </div>
                    </div>
                </div>
            </nav>

            {/* Hero Section */}
            <section className="relative pt-20 pb-32 overflow-hidden">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
                    <div className="lg:grid lg:grid-cols-2 lg:gap-12 items-center">
                        <div className="mb-12 lg:mb-0">
                            <div className="inline-block px-4 py-1.5 mb-6 text-xs font-bold tracking-widest text-indigo-600 uppercase bg-indigo-50 dark:bg-indigo-900/30 rounded-full">
                                Clínica Veterinaria Premium
                            </div>
                            <h1 className="text-5xl lg:text-7xl font-black leading-tight mb-8">
                                {getSetting('hero_title', 'Cuidado Médico de Excelencia')}
                            </h1>
                            <p className="text-xl text-gray-600 dark:text-gray-400 mb-10 leading-relaxed max-w-xl">
                                {getSetting('hero_subtitle', 'Especialistas en bienestar animal con hospitalización y estética profesional.')}
                            </p>
                            <div className="flex flex-col sm:flex-row gap-4">
                                <a
                                    href={`https://wa.me/${getSetting('contact_whatsapp', '')}`}
                                    className="px-8 py-4 bg-indigo-600 text-white rounded-2xl text-lg font-bold hover:bg-indigo-700 transition shadow-2xl shadow-indigo-200 dark:shadow-none text-center"
                                >
                                    Agendar Cita
                                </a>
                                <a
                                    href="#servicios"
                                    className="px-8 py-4 bg-white dark:bg-gray-900 border-2 border-gray-100 dark:border-gray-800 rounded-2xl text-lg font-bold hover:border-indigo-200 transition text-center"
                                >
                                    Ver Servicios
                                </a>
                            </div>
                        </div>
                        <div className="relative">
                            <div className="absolute -inset-4 bg-gradient-to-r from-indigo-500 to-purple-500 rounded-3xl blur-2xl opacity-10"></div>
                            <img
                                src={getSetting('hero_image', 'https://images.unsplash.com/photo-1576201836106-db1758fd1c97?auto=format&fit=crop&q=80&w=1200')}
                                alt="Veterinary Care"
                                className="relative rounded-3xl shadow-2xl w-full h-[500px] object-cover"
                            />
                        </div>
                    </div>
                </div>
            </section>

            {/* Services Section */}
            <section id="servicios" className="py-32 bg-gray-50 dark:bg-gray-900/50">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="text-center mb-20">
                        <h2 className="text-4xl font-black mb-4">Servicios Especializados</h2>
                        <p className="text-gray-500 dark:text-gray-400">Ofrecemos lo mejor en salud y estética animal</p>
                    </div>

                    <div className="grid md:grid-cols-3 gap-8">
                        {/* Estetica */}
                        <div className="bg-white dark:bg-gray-800 p-10 rounded-3xl shadow-xl shadow-gray-200/50 dark:shadow-none hover:-translate-y-2 transition duration-300 group">
                            <div className="w-16 h-16 bg-pink-100 dark:bg-pink-900/30 rounded-2xl flex items-center justify-center text-3xl mb-8 group-hover:scale-110 transition">🛁</div>
                            <h3 className="text-2xl font-bold mb-4">Estética Canina</h3>
                            <p className="text-gray-500 dark:text-gray-400 mb-6 leading-relaxed">
                                {getSetting('service_grooming_desc', 'Estética profesional con productos dermatológicos.')}
                            </p>
                            <span className="text-indigo-600 font-bold flex items-center gap-2 cursor-pointer">
                                Ver más <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5l7 7-7 7"></path></svg>
                            </span>
                        </div>

                        {/* Hospitalización */}
                        <div className="bg-white dark:bg-gray-800 p-10 rounded-3xl shadow-xl shadow-gray-200/50 dark:shadow-none hover:-translate-y-2 transition duration-300 group">
                            <div className="w-16 h-16 bg-blue-100 dark:bg-blue-900/30 rounded-2xl flex items-center justify-center text-3xl mb-8 group-hover:scale-110 transition">🏥</div>
                            <h3 className="text-2xl font-bold mb-4">Hospitalización</h3>
                            <p className="text-gray-500 dark:text-gray-400 mb-6 leading-relaxed">
                                {getSetting('service_hosp_desc', 'Monitoreo 24/7 con equipamiento de última generación.')}
                            </p>
                            <span className="text-indigo-600 font-bold flex items-center gap-2 cursor-pointer">
                                Ver más <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5l7 7-7 7"></path></svg>
                            </span>
                        </div>

                        {/* Revisión */}
                        <div className="bg-white dark:bg-gray-800 p-10 rounded-3xl shadow-xl shadow-gray-200/50 dark:shadow-none hover:-translate-y-2 transition duration-300 group">
                            <div className="w-16 h-16 bg-green-100 dark:bg-green-900/30 rounded-2xl flex items-center justify-center text-3xl mb-8 group-hover:scale-110 transition">🩺</div>
                            <h3 className="text-2xl font-bold mb-4">Revisión General</h3>
                            <p className="text-gray-500 dark:text-gray-400 mb-6 leading-relaxed">
                                {getSetting('service_checkup_desc', 'Revisiones preventivas integrales para una vida saludable.')}
                            </p>
                            <span className="text-indigo-600 font-bold flex items-center gap-2 cursor-pointer">
                                Ver más <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5l7 7-7 7"></path></svg>
                            </span>
                        </div>
                    </div>
                </div>
            </section>

            {/* CTA Section */}
            <section id="contacto" className="py-32">
                <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="bg-gray-900 dark:bg-indigo-600 rounded-[3rem] p-12 lg:p-20 text-white text-center shadow-3xl">
                        <h2 className="text-4xl lg:text-6xl font-black mb-8 leading-tight">¿Listo para la mejor atención veterinaria?</h2>
                        <div className="flex flex-wrap justify-center gap-8 mb-12">
                            <div className="flex items-center gap-4 bg-white/10 px-6 py-4 rounded-2xl backdrop-blur-sm">
                                <span className="text-2xl">📞</span>
                                <span className="font-bold">{getSetting('contact_phone', '')}</span>
                            </div>
                            <div className="flex items-center gap-4 bg-white/10 px-6 py-4 rounded-2xl backdrop-blur-sm">
                                <span className="text-2xl">📍</span>
                                <span className="font-bold">{getSetting('contact_address', '')}</span>
                            </div>
                        </div>
                        <a
                            href={`https://wa.me/${getSetting('contact_whatsapp', '')}`}
                            className="inline-block px-12 py-5 bg-white text-indigo-600 rounded-2xl text-xl font-black hover:bg-gray-50 transition"
                        >
                            Contactar vía WhatsApp
                        </a>
                    </div>
                </div>
            </section>

            {/* Footer */}
            <footer className="py-12 border-t border-gray-100 dark:border-gray-800 text-center">
                <div className="flex justify-center items-center gap-2 mb-6">
                    <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center text-white font-bold">C</div>
                    <span className="font-black tracking-tighter">CANBULL VET</span>
                </div>
                <p className="text-sm text-gray-500">&copy; {new Date().getFullYear()} Canbull Centro Veterinario. Todos los derechos reservados.</p>
            </footer>
        </div>
    );
}
