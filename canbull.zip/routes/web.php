<?php

use App\Http\Controllers\ProfileController;
use Illuminate\Foundation\Application;
use Illuminate\Support\Facades\Route;
use Inertia\Inertia;

Route::get('/', function () {
    $settings = \App\Models\SiteSetting::all()->pluck('value', 'key');

    return Inertia::render('Welcome', [
        'settings' => $settings,
        'canLogin' => Route::has('login'),
        'canRegister' => Route::has('register'),
    ]);
});

// Public Carnet
Route::get('/carnet/{uuid}', [\App\Http\Controllers\PublicPetController::class, 'carnet'])->name('public.carnet');

Route::get('/dashboard', function () {
    return Inertia::render('Dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');

    Route::get('/pets/search', [\App\Http\Controllers\PetController::class, 'search'])->name('pets.search');
    Route::post('/pets/{pet}/link-owner', [\App\Http\Controllers\PetController::class, 'linkOwner'])->name('pets.link-owner');
    Route::resource('pets', \App\Http\Controllers\PetController::class);
    Route::resource('clients', \App\Http\Controllers\ClientController::class);

    Route::get('/breeds/search', [\App\Http\Controllers\PetBreedController::class, 'search'])->name('breeds.search');
    Route::resource('breeds', \App\Http\Controllers\PetBreedController::class);
    Route::get('/pets/{pet}/medical-records/create', [\App\Http\Controllers\MedicalRecordController::class, 'create'])->name('medical-records.create');
    Route::post('/pets/{pet}/medical-records', [\App\Http\Controllers\MedicalRecordController::class, 'store'])->name('medical-records.store');
    Route::get('/medical-records/{medicalRecord}', [\App\Http\Controllers\MedicalRecordController::class, 'show'])->name('medical-records.show');

    Route::get('/consents', [\App\Http\Controllers\ConsentController::class, 'index'])->name('consents.index');
    Route::get('/pets/{pet}/consents/create', [\App\Http\Controllers\ConsentController::class, 'create'])->name('consents.create');
    Route::post('/pets/{pet}/consents', [\App\Http\Controllers\ConsentController::class, 'store'])->name('consents.store');
    Route::get('/consents/{consent}', [\App\Http\Controllers\ConsentController::class, 'show'])->name('consents.show');

    // Agenda Médica
    Route::resource('appointments', \App\Http\Controllers\AppointmentController::class);

    // Carnet de Vacunación / Preventivos
    Route::post('preventive-records', [\App\Http\Controllers\PreventiveRecordController::class, 'store'])->name('preventive-records.store');
    Route::delete('preventive-records/{preventiveRecord}', [\App\Http\Controllers\PreventiveRecordController::class, 'destroy'])->name('preventive-records.destroy');

    // Gestión Web
    Route::get('/settings/web', [\App\Http\Controllers\SiteSettingController::class, 'index'])->name('settings.web.index');
    Route::patch('/settings/web', [\App\Http\Controllers\SiteSettingController::class, 'update'])->name('settings.web.update');
});

require __DIR__.'/auth.php';
