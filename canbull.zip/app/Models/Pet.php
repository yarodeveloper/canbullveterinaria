<?php

namespace App\Models;

use App\Traits\Auditable;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Pet extends Model
{
    use HasFactory, SoftDeletes, Auditable;

    protected static function boot()
    {
        parent::boot();
        static::creating(function ($model) {
            if (empty($model->uuid)) {
                $model->uuid = (string) \Illuminate\Support\Str::uuid();
            }
        });
    }

    protected $fillable = [
        'uuid',
        'name',
        'species',
        'breed',
        'gender',
        'dob',
        'color',
        'microchip',
        'weight',
        'notes',
        'user_id',
        'branch_id',
        'is_aggressive',
        'allergies',
        'chronic_conditions',
    ];

    protected $casts = [
        'dob' => 'date',
        'weight' => 'decimal:2',
    ];

    public function owners()
    {
        return $this->belongsToMany(User::class)->withPivot('relation_type', 'is_primary')->withTimestamps();
    }

    public function owner()
    {
        // For compatibility with existing code, returns the first primary owner or the first owner found
        return $this->belongsTo(User::class, 'user_id');
    }

    public function branch()
    {
        return $this->belongsTo(Branch::class);
    }

    public function medicalRecords()
    {
        return $this->hasMany(MedicalRecord::class);
    }

    public function appointments()
    {
        return $this->hasMany(Appointment::class);
    }

    public function consents()
    {
        return $this->hasMany(Consent::class);
    }

    public function preventiveRecords()
    {
        return $this->hasMany(PreventiveRecord::class);
    }
}
