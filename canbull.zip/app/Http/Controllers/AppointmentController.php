<?php

namespace App\Http\Controllers;

use App\Models\Appointment;
use App\Models\Pet;
use App\Models\User;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;

class AppointmentController extends Controller
{
    public function index(Request $request)
    {
        $branchId = Auth::user()->branch_id;
        $date = $request->get('date', Carbon::today()->toDateString());
        
        $appointments = Appointment::where('branch_id', $branchId)
            ->whereDate('start_time', $date)
            ->with(['pet', 'client', 'veterinarian'])
            ->orderBy('start_time')
            ->get();

        return Inertia::render('Appointments/Index', [
            'appointments' => $appointments,
            'selectedDate' => $date
        ]);
    }

    public function create()
    {
        $branchId = Auth::user()->branch_id;
        
        $pets = Pet::where('branch_id', $branchId)->with('owner')->get();
        $veterinarians = User::where('branch_id', $branchId)
            ->whereIn('role', ['admin', 'veterinarian'])
            ->get(['id', 'name']);

        return Inertia::render('Appointments/Create', [
            'pets' => $pets,
            'veterinarians' => $veterinarians
        ]);
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'pet_id' => 'required|exists:pets,id',
            'veterinarian_id' => 'nullable|exists:users,id',
            'start_time' => 'required|date',
            'duration' => 'required|integer|min:15|max:240', // duration in minutes
            'type' => 'required|in:consultation,surgery,grooming,follow-up,emergency',
            'reason' => 'nullable|string',
        ]);

        $pet = Pet::findOrFail($validated['pet_id']);
        
        $appointment = new Appointment($validated);
        $appointment->user_id = $pet->user_id; // Primary owner
        $appointment->branch_id = Auth::user()->branch_id;
        $appointment->end_time = Carbon::parse($validated['start_time'])->addMinutes($validated['duration']);
        $appointment->status = 'scheduled';
        $appointment->save();

        return redirect()->route('appointments.index')
            ->with('message', 'Cita agendada correctamente.');
    }

    public function update(Request $request, Appointment $appointment)
    {
        if ($appointment->branch_id !== Auth::user()->branch_id) {
            abort(403);
        }

        $validated = $request->validate([
            'status' => 'required|in:scheduled,confirmed,in-progress,completed,cancelled,no-show',
            'veterinarian_id' => 'nullable|exists:users,id',
            'start_time' => 'nullable|date',
            'reason' => 'nullable|string',
        ]);

        $appointment->update($validated);

        return redirect()->back()->with('message', 'Estado de la cita actualizado.');
    }

    public function destroy(Appointment $appointment)
    {
        if ($appointment->branch_id !== Auth::user()->branch_id) {
            abort(403);
        }

        $appointment->delete();

        return redirect()->route('appointments.index')
            ->with('message', 'Cita eliminada.');
    }
}
